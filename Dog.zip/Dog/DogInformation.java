/*
Date : 2020.06.16
Author : 1팀(구민성 김상민 김성진 김혁)
Description : 유니개프
Version : 1.0
*/



package Dog;

public class DogInformation {
	
	private int code;
	private String name;
	private int age;
	private String size;
	private String kind;
	private String gender;
	private String country;
	private String date;
	private String character;
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getCharacter() {
		return character;
	}
	public void setCharacter(String character) {
		this.character = character;
	}
	public DogInformation(int code, String name, int age, String size, String kind, String gender, String country,
			String date, String character) {
		super();
		this.code = code;
		this.name = name;
		this.age = age;
		this.size = size;
		this.kind = kind;
		this.gender = gender;
		this.country = country;
		this.date = date;
		this.character = character;
	}
	public DogInformation() {
		super();
	}
	@Override
	public String toString() {
		return "DogInformation [code=" + code + ", name=" + name + ", age=" + age + ", size=" + size + ", kind=" + kind
				+ ", gender=" + gender + ", country=" + country + ", date=" + date + ", character=" + character + "]";
	}
	
	

}
