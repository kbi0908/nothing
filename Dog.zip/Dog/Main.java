/*
Date : 2020.06.16
Author : 1팀(구민성 김상민 김성진 김혁)
Description : 유니개프
Version : 1.0
*/

package Dog;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean run = true;
		boolean eRun = false;
		boolean jRun = false;
		boolean centerLogin = false;
		int language = 1;
		MemberSQL sql = new MemberSQL();
		MemberClient MC = new MemberClient();
		boolean systemRun = run;

		int menu, subMenu;
		int subSubMenu;
		sql.connect();
		boolean login = false;
		char center = 'x';
		String ID = "";
		String PW = "";
		int randomCode = sql.randomGoods();
		while (systemRun) {
			
			switch (language) {
			case 1:

				while (run) {
					System.out.println("┌───────────────┬───────────────┐");
					System.out.println("│1.회원\t\t│2.유기견 \t\t│\n│3.나눔장터\t│4.쇼핑몰 \t\t│\n│5.Language\t│6.종료    \t\t│");
					System.out.println("└───────────────┴───────────────┘");
					System.out.print("입력 >> ");
					menu = sc.nextInt();
					switch (menu) {
					case 1:
						System.out.println("┌───────────────────────────────────────┐");
						System.out.println("│1.회원가입\t2.로그인 \t\t3.로그아웃\t│\n│4.센터등록\t5.마이페이지\t6.처음으로\t│");
						System.out.println("└───────────────────────────────────────┘");
						System.out.print("입력 >> ");
						subMenu = sc.nextInt();
						switch (subMenu) {
						case 1:
							System.out.println("----------회원가입---------");
							sql.insertClient(MC);
							break;
						case 2:
							while(!login) {
							System.out.println("----------로그인-----------");
							System.out.println("아이디를 입력하세요  : ");
							ID = sc.next();
							System.out.println("비밀번호를 입력하세요  : ");
							PW = sc.next();
							login = sql.logIn(ID, PW);
							if (!login) {
								System.out.println("로그인실패");
							}}
							break;
						case 3:
							login = sql.logOut(login);

							break;
						case 4:
							center = sql.center(ID, PW);
							if (center == '×') {
								System.out.println("센터등록에 실패하였습니다. 로그인을 해주세요");
							}

							break;
						case 5:
							if (login) {
								System.out.println("┌─────────────────────────────────────────────────────────┐");
								System.out.println("│1.정보출력\t2.포인트확인\t3.비밀번호변경\t4.포인트충전   │");
								System.out.println("└─────────────────────────────────────────────────────────┘");
								System.out.print("입력 >> ");
								subSubMenu = sc.nextInt();
								switch (subSubMenu) {
								case 1:
									sql.memberInfo(ID);
									break;
								case 2:
									sql.checkPoint(ID);
									break;
								case 3:
									sql.changePW(PW);
									break;
								case 4:
									sql.exchange(ID);
									break;
								default:
									System.out.println("잘못입력하였습니다 처음으로 돌아갑니다.");
									break;

								}
							} else {
								System.out.println("로그인을 해주세요.");
							}
							break;
						case 6:
							continue;
						default:
							System.out.println("잘못입력하였습니다 처음으로 돌아갑니다.");
							break;
						}
						break;
					case 2:
						System.out.println("┌───────────────┬───────────────┐");
						System.out.println("│1.유기견 등록\t│2.프로필보기\t│\n│3.입양하기\t│4.국가별검색\t│\n│5.돌아가기\t│\t\t│");
						System.out.println("└───────────────┴───────────────┘");
						System.out.print("입력 >> ");
						subSubMenu = sc.nextInt();
						switch (subSubMenu) {
						case 1:
							centerLogin=sql.centerLogin(ID);
							if (centerLogin) {
								sql.insertDogClient();
							} else {
								System.out.println("등록된 센터만 유기견을 등록할 수 있습니다.");
							}
							break;
						case 2:
							
							if(sql.dogInfo()) {
							System.out.println("┌────────────────────────────────┐");
							System.out.println("│1.세부정보보기 \t\t2.돌아가기\t │");
							System.out.println("└────────────────────────────────┘");
							System.out.print("입력 >>");
							int info = sc.nextInt();
							switch (info) {
							case 1:
								System.out.print("세부정보보기\n코드선택>>");
								int dInfo = sc.nextInt();
								sql.detailInfo(dInfo);
								break;
							case 2:
								
								break;
							default:
								System.out.println("잘못된 메뉴입니다.");
								break;
							}}else {System.out.println("프로필이 없습니다.");}
							break;
						case 3:
							if (login) {
								boolean adoption=sql.adoption();
								if(!adoption) {
									System.out.println("해당코드는 유기견이 없습니다.");
								}
								
							} else {
								System.out.println("회원만 입양이 가능합니다.");
							}
							break;
						case 4:
							sql.countryInfo();
							sql.searchDog();
							break;
						case 5:
							continue;

						default:
							System.out.println("잘못입력하였습니다 처음으로 돌아갑니다.");
							break;
						}
						break;
					case 3:
						System.out.println("┌───────────────────────────────────────┐");
						System.out.println("│1.물건등록\t2.목록보기    \t3.돌아가기\t│");
						System.out.println("└───────────────────────────────────────┘");
						System.out.print("입력 >> ");
						subMenu = sc.nextInt();
						switch (subMenu) {
						case 1:
							if (login) {
								sql.insertShared();
							} else {
								System.out.println("회원만 물건등록이 가능합니다");
							}
							break;
						case 2:
							sql.divideInfo();

							if (login) {
								System.out.println("┌ㅇ─────────────────────┐");
								System.out.println("│1.선택하기\t2.돌아가기│");
								System.out.println("└─────────────────────ㅇ┘");
								System.out.print("입력 >> ");
								int bringMenu = sc.nextInt();
								switch (bringMenu) {
								case 1:
									boolean bring =sql.bring();
									if(!bring) {System.out.println("해당 코드의 물건은 없습니다.");}
									break;
								case 2:
									break;
								default:
									System.out.println("잘못된 입력입니다.");
									break;
								}
							}else {System.out.println("회원만 물건을 가져가실수 있습니다.");}
							break;
						case 3:
							continue;
						default:
							System.out.println("잘못입력하였습니다 처음으로 돌아갑니다.");
							break;
						}
						break;
					case 4:
						System.out.println("┌쇼핑몰─────────────────────┐");
						System.out.println("│1.사이즈로 검색하기\t2.인기상품보기│\n│3.오늘의 특가상품보기\t4.전체보기\t  │\n│5.구매하기\t6.돌아가기\t  │");
						System.out.println("└─────────────────────────┘");
						System.out.print("입력 >> ");
						subMenu = sc.nextInt();
						switch (subMenu) {
						case 1:
							System.out.println("애완견의 사이즈를 입력하세요 (S,M,L)");
							System.out.print("입력 >> ");
							String dSize = sc.next();
							sql.sizeInfo(dSize);
							if (login) {

								System.out.println("☆★☆★☆★구매기능으로 넘어갑니다.☆★☆★☆★");

								sql.perchase(ID, PW,randomCode);
							} else {
								System.out.println("로그인시 구매 가능합니다.");
							}
							break;
						case 2:
							sql.popularGoods();
							if (login) {

								System.out.println("☆★☆★☆★구매기능으로 넘어갑니다.☆★☆★☆★");

								sql.perchase(ID, PW,randomCode);
							} else {
								System.out.println("로그인시 구매 가능합니다.");
							}
							break;
						case 3:
							sql.todayGoods(randomCode);

							break;
						case 4:
							sql.shopInfo(randomCode);
							if (login) {

								System.out.println("☆★☆★☆★구매기능으로 넘어갑니다.☆★☆★☆★");

								sql.perchase(ID, PW,randomCode);
							} else {
								System.out.println("로그인시 구매 가능합니다.");
							}
							break;
						case 5:
							sql.perchase(ID, PW,randomCode);
							break;
						case 6:
							continue;
						default:
							System.out.println("잘못입력하였습니다 처음으로 돌아갑니다.");
							break;

						}

						break;
					case 5:
						System.out.println("1.한국어\t2.ENGLISH\t3.日本語");
						System.out.print("입력 >> ");
						subMenu = sc.nextInt();
						switch (subMenu) {
						case 1:
							language = 1;
							run = true;
							eRun = false;
							jRun = false;
							break;
						case 2:
							run = false;
							eRun = true;
							jRun = false;
							language = 2;
							break;
						case 3:
							run = false;
							eRun = false;
							jRun = true;
							language = 3;
							break;
						default:
							System.out.println("잘못입력하였습니다 처음으로 돌아갑니다.");
							break;
						}
						break;
					case 6:
						System.out.println("프로그램 종료합니다.");
						sql.disconnect();
						run = !run;
						systemRun = !systemRun;
						break;
					default:
						System.out.println("잘못입력하였습니다 처음으로 돌아갑니다.");
						break;

					}

				} // korean
				break;
			case 2:
				while (eRun) {
					System.out.println("┌───────────────────────┬───────────────┐");
					System.out.println(
							"│1.member\t\t│2.Abandoned dog│\n│3.Sharing Market\t│4.shop \t│\n│5.Language\t\t│6.Exit    \t│");
					System.out.println("└───────────────────────┴───────────────┘");
					System.out.print("input >> ");
					menu = sc.nextInt();
					switch (menu) {
					case 1:
						System.out.println("┌────────────────────────────────────────────────┐");
						System.out.println(
								"│(1)Sign Up\t(2)login \t\t(3)logout│\n│(4)Center registration\t(5)mypage\t(6)back\t │");
						System.out.println("└────────────────────────────────────────────────┘");
						System.out.print("input >> ");
						subMenu = sc.nextInt();
						switch (subMenu) {
						case 1:
							System.out.println("----------Sign Up---------");
							sql.insertClient(MC);
							break;
						case 2:
							System.out.println("----------login-----------");
							System.out.println("insert id  : ");
							ID = sc.next();
							System.out.println("insert pw  : ");
							PW = sc.next();
							login = sql.logIn(ID, PW);
							if (!login) {
								System.out.println("fail");
							}
							break;
						case 3:
							login = sql.logOut(login);

							break;
						case 4:
							center = sql.center(ID, PW);
							if (center == '×') {
								System.out.println("fail, need to login");
							}

							break;
						case 5:
							if (login) {
								System.out.println(
										"┌─────────────────────────────────────────────────────────────────────┐");
								System.out.println("│1.info\t\t2.point\t\t3.change pw\t\t4.charge point│");
								System.out.println(
										"└─────────────────────────────────────────────────────────────────────┘");
								System.out.print("input >> ");
								subSubMenu = sc.nextInt();
								switch (subSubMenu) {
								case 1:
									sql.memberInfo(ID);
									break;
								case 2:
									sql.checkPoint(ID);
									break;
								case 3:
									sql.changePW(PW);
									break;
								case 4:
									sql.exchange(ID);
									break;
								default:
									System.out.println("fail.");
									break;

								}
							} else {
								System.out.println("need to login");
							}
							break;
						case 6:
							continue;
						default:
							System.out.println("fail");
							break;
						}
						break;
					case 2:
						System.out.println("┌───────────────┬───────────────┐");
						System.out.println("│1.registe A.D \t│2.profile\t│\n│3.adopt\t│4.search\t│\n│5.back\t\t│\t\t│");
						System.out.println("└───────────────┴───────────────┘");
						System.out.print("input >> ");
						subSubMenu = sc.nextInt();
						switch (subSubMenu) {
						case 1:
							if (sql.center(ID, PW) == ('○')) {
								sql.insertDogClient();
							} else {
								System.out.println("need to registe center");
							}
							break;
						case 2:
							sql.dogInfo();
							break;
						case 3:
							if (sql.logIn(ID, PW)) {
								sql.adoption();
							} else {
								System.out.println("Only members can adopt.");
							}
							break;
						case 4:
							sql.searchDog();
							break;
						case 5:
							continue;

						default:
							System.out.println("You entered the wrong number.");
							break;
						}
						break;
					case 3:
						System.out.println("1.regist goods\t2.show\n3.back");
						System.out.print("input >> ");
						subMenu = sc.nextInt();
						switch (subMenu) {
						case 1:
							if (login) {
								sql.insertShared();
							} else {
								System.out.println("Only members can adopt." + "");
							}
							break;
						case 2:
							sql.divideInfo();
							if (login) {
								sql.bring();
							}
							break;
						case 3:
							continue;
						default:
							System.out.println("You entered the wrong number.");
							break;
						}
						break;
					case 4:
						System.out.println("1.size\t2.best5\n3.event\t4.show all\n5.buy\t6.back");
						System.out.print("input >> ");
						subMenu = sc.nextInt();
						switch (subMenu) {
						case 1:
							System.out.println("input your pet size (S,M,L)");
							System.out.print("input >> ");
							String dSize = sc.next();
							sql.sizeInfo(dSize);
							if (login) {

								System.out.println("☆★☆★☆★  ENTER BUY  ☆★☆★☆★");

								sql.perchase(ID, PW,randomCode);
							} else {
								System.out.println("need to login");
							}
							break;
						case 2:
							sql.popularGoods();
							if (login) {

								System.out.println("☆★☆★☆★  ENTER BUY  ☆★☆★☆★");

								sql.perchase(ID, PW,randomCode);
							} else {
								System.out.println("need to login");
							}
							break;
						case 3:
							sql.todayGoods(randomCode);

							break;
						case 4:
							sql.shopInfo(randomCode);
							if (login) {

								System.out.println("☆★☆★☆★  ENTER BUY  ☆★☆★☆★");

								sql.perchase(ID, PW,randomCode);
							} else {
								System.out.println("need to login");
							}
							break;
						case 5:
							sql.perchase(ID, PW,randomCode);
							break;
						case 6:
							continue;
						default:
							System.out.println("You entered the wrong number.");
							break;

						}

						break;
					case 5:
						System.out.println("1.한국어\t2.ENGLISH\t3.日本語");
						System.out.print("input >> ");
						subMenu = sc.nextInt();
						switch (subMenu) {
						case 1:
							language = 1;
							run = true;
							eRun = false;
							jRun = false;
							break;
						case 2:
							run = false;
							eRun = true;
							jRun = false;
							language = 2;
							break;
						case 3:
							run = false;
							eRun = false;
							jRun = true;
							language = 3;
							break;
						default:
							System.out.println("You entered the wrong number.");
							break;
						}
						break;
					case 6:
						System.out.println("byebye~");
						sql.disconnect();
						eRun = !eRun;
						systemRun = !systemRun;
						break;
					default:
						System.out.println("You entered the wrong number.");
						break;

					}

				} // english
				break;
			case 3:
				while (jRun) {
					System.out.println("┌───────────────┬───────────────┐");
					System.out.println(
							"│1.会員\t\t│2.遺棄犬 \t\t│\n│3.分かち合い市場\t│4.ショッピングモール \t│\n│5.Language\t│6.終了    \t\t│");
					System.out.println("└───────────────┴───────────────┘");
					System.out.print("メニュー >> ");
					menu = sc.nextInt();
					switch (menu) {
					case 1:
						System.out.println("┌────────────────────────────────────────┐");
						System.out.println("│(1)会員登録\t(2)login \t(3)logout│\n│(4)センター登録\t(5)mypage\t(6)バック\t │");
						System.out.println("└────────────────────────────────────────┘");
						System.out.print("メニュー >> ");
						subMenu = sc.nextInt();
						switch (subMenu) {
						case 1:
							System.out.println("----------会員登録---------");
							sql.insertClient(MC);
							break;
						case 2:
							System.out.println("----------login-----------");
							System.out.println("id  : ");
							ID = sc.next();
							System.out.println("pw  : ");
							PW = sc.next();
							login = sql.logIn(ID, PW);
							if (!login) {
								System.out.println("不合格");
							}
							break;
						case 3:
							login = sql.logOut(login);

							break;
						case 4:
							center = sql.center(ID, PW);
							if (center == '×') {
								System.out.println("不合格");
							}

							break;
						case 5:
							if (login) {
								System.out.println("┌─────────────────────────────────────────────────────────┐");
								System.out.println("│1.情報\t\t2.POINT\t\t3.シフト PW\t4.充電  POINT│");
								System.out.println("└─────────────────────────────────────────────────────────┘");
								System.out.print("メニュー >> ");
								subSubMenu = sc.nextInt();
								switch (subSubMenu) {
								case 1:
									sql.memberInfo(ID);
									break;
								case 2:
									sql.checkPoint(ID);
									break;
								case 3:
									sql.changePW(PW);
									break;
								case 4:
									sql.exchange(ID);
									break;
								default:
									System.out.println("不合格");
									break;

								}
							} else {
								System.out.println("不合格");
							}
							break;
						case 6:
							continue;
						default:
							System.out.println("不合格");
							break;
						}
						break;
					case 2:
						System.out.println("┌───────────────┬───────────────┐");
						System.out.println("│1.遺棄犬  登録\t│2.PROFILE\t│\n│3.養子縁組\t│4.探す\t\t│\n│5.バック\t\t│\t\t│");
						System.out.println("└───────────────┴───────────────┘");
						System.out.print("メニュー >> ");
						subSubMenu = sc.nextInt();
						switch (subSubMenu) {
						case 1:
							if (sql.center(ID, PW) == ('○')) {
								sql.insertDogClient();
							} else {
								System.out.println("不合格");
							}
							break;
						case 2:
							sql.dogInfo();
							break;
						case 3:
							if (sql.logIn(ID, PW)) {
								sql.adoption();
							} else {
								System.out.println("不合格");
							}
							break;
						case 4:
							sql.searchDog();
							break;
						case 5:
							continue;

						default:
							System.out.println("不合格");
							break;
						}
						break;
					case 3:
						System.out.println("1.モノ 登録\t2.モノ 公演\n3.バック");
						subMenu = sc.nextInt();
						switch (subMenu) {
						case 1:
							if (login) {
								sql.insertShared();
							} else {
								System.out.println("不合格");
							}
							break;
						case 2:
							sql.divideInfo();
							if (login) {
								sql.bring();
							}
							break;
						case 3:
							continue;
						default:
							System.out.println("不合格");
							break;
						}
						break;
					case 4:
						System.out.println("1.サイズ\t2.ベスト5\n3.出来事\t4.すべて\n5.購入\t6.バック");
						System.out.print("メニュー >> ");
						subMenu = sc.nextInt();
						switch (subMenu) {
						case 1:
							System.out.println("サイズ (S,M,L)");
							String dSize = sc.next();
							sql.sizeInfo(dSize);
							if (login) {

								System.out.println("☆★☆★☆★購入☆★☆★☆★");

								sql.perchase(ID, PW,randomCode);
							} else {
								System.out.println("不合格");
							}
							break;
						case 2:
							sql.popularGoods();
							if (login) {

								System.out.println("☆★☆★☆★購入☆★☆★☆★");

								sql.perchase(ID, PW,randomCode);
							} else {
								System.out.println("不合格");
							}
							break;
						case 3:
							sql.todayGoods(randomCode);

							break;
						case 4:
							sql.shopInfo(randomCode);
							if (login) {

								System.out.println("☆★☆★☆★購入☆★☆★☆★");

								sql.perchase(ID, PW,randomCode);
							} else {
								System.out.println("不合格");
							}
							break;
						case 5:
							sql.perchase(ID, PW,randomCode);
							break;
						case 6:
							continue;
						default:
							System.out.println("不合格");
							break;

						}

						break;
					case 5:
						System.out.println("1.한국어\t2.ENGLISH\t3.日本語");
						subMenu = sc.nextInt();
						switch (subMenu) {
						case 1:
							language = 1;
							run = true;
							eRun = false;
							jRun = false;
							break;
						case 2:
							run = false;
							eRun = true;
							jRun = false;
							language = 2;
							break;
						case 3:
							run = false;
							eRun = false;
							jRun = true;
							language = 3;
							break;
						default:
							System.out.println("不合格");
							break;
						}
						break;
					case 6:
						System.out.println("終了");
						sql.disconnect();
						jRun = !jRun;
						systemRun = !systemRun;
						break;
					default:
						System.out.println("不合格");
						break;

					}

				} // japaness
				break;
			default:
				break;
			}

		}
	}
}
