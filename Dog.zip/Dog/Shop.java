/*
Date : 2020.06.16
Author : 1팀(구민성 김상민 김성진 김혁)
Description : 유니개프
Version : 1.0
*/



package Dog;

public class Shop {
	private int code;
	private String name;
	private int sm;
	private int me;
	private int la;
	private int price;
	private int popul;
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSm() {
		return sm;
	}
	public void setSm(int sm) {
		this.sm = sm;
	}
	public int getMe() {
		return me;
	}
	public void setMe(int me) {
		this.me = me;
	}
	public int getLa() {
		return la;
	}
	public void setLa(int la) {
		this.la = la;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getPopul() {
		return popul;
	}
	public void setPopul(int popul) {
		this.popul = popul;
	}
	public Shop(int code, String name, int sm, int me, int la, int price, int popul) {
		super();
		this.code = code;
		this.name = name;
		this.sm = sm;
		this.me = me;
		this.la = la;
		this.price = price;
		this.popul = popul;
	}
	public Shop() {
		super();
	}
	@Override
	public String toString() {
		return "Shop [code=" + code + ", name=" + name + ", sm=" + sm + ", me=" + me + ", la=" + la + ", price=" + price
				+ ", popul=" + popul + "]";
	}
	
	
}
