/*
Date : 2020.06.16
Author : 1팀(구민성 김상민 김성진 김혁)
Description : 유니개프
Version : 1.0
*/



package Dog;

public class Divide {
	private int code;
	private String use;
	private String size;
	private String name;
	private String date;
	private String status;
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getUse() {
		return use;
	}
	public void setUse(String use) {
		this.use = use;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Divide(int code, String use, String size, String name, String date, String status) {
		super();
		this.code = code;
		this.use = use;
		this.size = size;
		this.name = name;
		this.date = date;
		this.status = status;
	}
	public Divide() {
		super();
	}
	@Override
	public String toString() {
		return "Shop [code=" + code + ", use=" + use + ", size=" + size + ", name=" + name + ", date=" + date
				+ ", status=" + status + "]";
	}
	
	

}
