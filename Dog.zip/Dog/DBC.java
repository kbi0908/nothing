package Dog;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBC {
	
	public static Connection DBconnect() {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@192.168.0.175:1521:XE";
			String user = "PROJECT";
			String password = "1111";
			con = DriverManager.getConnection(url, user, password);
		} catch(ClassNotFoundException cne) {
			cne.printStackTrace();
			System.out.println("DB 접속 실패 : 드라이버 로딩 실패함");
		} catch(SQLException se) {
			se.printStackTrace();
			System.out.println("DB 접속 실패 : url, user, password 확인");
		}
		return con;
	}

}
