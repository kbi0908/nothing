/*
Date : 2020.06.16
Author : 1팀(구민성 김상민 김성진 김혁)
Description : 유니개프
Version : 1.0
*/



package Dog;

public class MemberClient {
	private String ID;
	private String PW;
	private String name;
	private String tel;

	private String email;
	private String country;
	private String pet;
	private int point;
	private boolean center;
	
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	
	public String getPW() {
		return PW;
	}
	public void setPW(String pW) {
		PW = pW;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	

	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	
	public String getPet() {
		return pet;
	}
	public void setPet(String pet) {
		this.pet = pet;
	}
	
	public int getPoint() {
		return point;
	}
	public void setPoint(int point) {
		this.point = point;
	}
	
	public boolean isCenter() {
		return center;
	}
	public void setCenter(boolean center) {
		this.center = center;
	}
	
	public MemberClient(String iD, String pW, String name, String tel, String email, String country, String pet,
			int point, boolean center) {
		super();
		ID = iD;
		PW = pW;
		this.name = name;
		this.tel = tel;

		this.email = email;
		this.country = country;
		this.pet = pet;
		this.point = point;
		this.center = center;
	}
	
	public MemberClient() {
		super();
	}
	
	@Override
	public String toString() {
		return "Client [ID=" + ID + ", PW=" + PW + ", name=" + name + ", tel=" + tel +  ", email="
				+ email + ", country=" + country + ", pet=" + pet + ", point=" + point + ", center=" + center + "]";
	}
	
}
