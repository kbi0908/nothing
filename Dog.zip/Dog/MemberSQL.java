/*
Date : 2020.06.16
Author : 1팀(구민성 김상민 김성진 김혁)
Description : 유니개프
Version : 1.0
*/

package Dog;

import java.sql.*;
import java.util.Scanner;

public class MemberSQL {
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	Scanner sc = new Scanner(System.in);

	public void connect() {
		con = DBC.DBconnect();
	}

	public void disconnect() {
		try {
			pstmt.close();
			con.close();

		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	// client
	public void insertClient(MemberClient client) {

		System.out.print("아이디 :");
		String ID = sc.next();
		System.out.print("비밀번호 :");
		String PW = sc.next();
		System.out.print("이름 :");
		String NAME = sc.next();
		System.out.print("전화번호 :");
		String TEL = sc.next();

		System.out.print("이메일 :");
		String Email = sc.next();
		System.out.print("국적 :");
		String COUNTRY = sc.next();
		System.out.print("애완동물 (o,x):");
		String PET = sc.next();

		String sql = "INSERT INTO MEMBER(M_ID, M_PW, M_NAME, M_TEL, M_EMAIL, M_COUNTRY, M_PET) VALUES(?, ?, ?, ?, ?, ?, ? )";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ID);
			pstmt.setString(2, PW);
			pstmt.setString(3, NAME);
			pstmt.setString(4, TEL);
			pstmt.setString(5, Email);
			pstmt.setString(6, COUNTRY);
			pstmt.setString(7, PET);

			int count = pstmt.executeUpdate();

			if (count > 0) {
				System.out.println("등록성공!");
			} else {
				System.out.println("등록실패..");
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	public boolean logIn(String ID, String PW) {
		String sql = "SELECT * FROM MEMBER WHERE M_ID = ? AND M_PW = ?";
		boolean success = false;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ID);
			pstmt.setString(2, PW);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				success = true;
				System.out.println("로그인 성공!");
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
		return success;
	}

	public boolean logOut(boolean logIn) {
		boolean logOut = false;
		if (logIn) {
			System.out.println("로그아웃 되었습니다.");
			logOut = false;
		} else {
			System.out.println("로그인 되어있지 않습니다.");
		}
		return logOut;
	}

	public char center(String ID, String PW) {
		String sql = "UPDATE MEMBER SET M_CENTER = '○' WHERE M_ID = ? AND M_PW = ?";
		char success = '×';
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ID);
			pstmt.setString(2, PW);
			int count = pstmt.executeUpdate();

			if (count == 1) {
				success = '○';
				System.out.println("센터 등록 성공!");
			} else {
				success = '×';
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
		return success;
	}

	public void memberInfo(String ID) {
		String sql = "SELECT SUBSTR(M_NAME, 1, LENGTH(M_NAME)-1 )||'*',"
				+ " SUBSTR(M_TEL, 1, LENGTH(M_TEL)-4)||'****', M_COUNTRY, M_PET FROM MEMBER WHERE M_ID = ?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ID);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println("이름 : " + rs.getString(1));
				System.out.println("전화번호 : " + rs.getString(2));
				System.out.println("국적 : " + rs.getString(3));
				System.out.println("반려동물 여부 : " + rs.getString(4));
				System.out.println("");
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	public void changePW(String PW) {

		String sql = "SELECT M_PW FROM MEMBER WHERE M_PW = ?";
		String sql1 = "UPDATE MEMBER SET M_PW = ? WHERE M_PW = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, PW);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				if (PW.equals(rs.getString(1))) {
					System.out.print("변경할 비밀번호 : ");
					String password = sc.next();

					pstmt = con.prepareStatement(sql1);
					pstmt.setString(1, password);
					pstmt.setString(2, PW);
					pstmt.executeUpdate();

					System.out.println("비밀번호가 변경되었습니다.");
				} else {
					System.out.println("잘못된 비밀번호입니다.");
				}
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}

	}

	public int checkPoint(String ID) {
		int stayPoint = 0;
		String sql = "SELECT M_POINT FROM MEMBER WHERE M_ID = ?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ID);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				System.out.println("잔여포인트 : " + rs.getInt(1) + "point");
				stayPoint = rs.getInt(1);
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
		return stayPoint;
	}

	public void exchange(String ID) {
		System.out.println("1.달러 \t2.원\t3.엔");
		System.out.print("입력 >> ");
		int menu = sc.nextInt();
		int money = 0;
		int point = 0;
		switch (menu) {
		case 1:
			System.out.print("충전할 금액 입력 : ");
			money = sc.nextInt();
			point = exchangeDallor(money);
			break;
		case 2:
			System.out.print("충전할 금액 입력 : ");
			money = sc.nextInt();
			point = exchangeWon(money);
			break;
		case 3:
			System.out.print("충전할 금액 입력 : ");
			money = sc.nextInt();
			point = exchangeEn(money);
			break;
		default:
			System.out.println("잘못된 메뉴입니다.");
			break;
		}

		String sql = "UPDATE MEMBER SET M_POINT = M_POINT + ? WHERE M_ID = ?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, point);
			pstmt.setString(2, ID);

			int count = pstmt.executeUpdate();

			if (count > 0) {
				System.out.println("충전 성공");
			} else {
				System.out.println("충전 실패");
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	private int exchangeEn(int money) {
		int point = 0;
		point = money / 10;
		return point;
	}

	private int exchangeWon(int money) {
		int point = 0;
		point = money / 100;
		return point;
	}

	private int exchangeDallor(int money) {
		int point = 0;
		point = money * 10;
		return point;
	}
	
	public boolean centerLogin(String ID) {
		boolean check = false;
		String sql = "SELECT M_CENTER FROM MEMBER WHERE M_ID = ?";
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ID);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				if(rs.getString(1).equals("○")) {
				check = true;
			}
			}
			
			
		} catch(SQLException se) {
			se.printStackTrace();
		}
		return check;
	}

//dog
	public void insertDogClient() {
		boolean random = true;
		int code = 0;
		while (random) {
			code = (int) (Math.random() * 9999) + 1;

			String sql = "SELECT D_CODE FROM DOG WHERE D_CODE = ?";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, code);
				rs = pstmt.executeQuery();

				if (rs.next()) {
				} else {
					random = false;
				}

			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		String size = "";
		String gender = "";
		System.out.print("이름입력 : ");
		String name = sc.next();
		System.out.print("나이 : ");
		int age = sc.nextInt();
		System.out.println("크기선택 :1.대형  2.중형 3.소형 ");
		System.out.print("입력 >> ");
		int sMenu = sc.nextInt();
		switch (sMenu) {
		case 1:
			size = "대형";
			break;
		case 2:
			size = "중형";
			break;
		case 3:
			size = "소형";
			break;
		default:
			System.out.println("잘못된 메뉴입니다.");
			break;
		}
		System.out.print("견종 : ");
		String kind = sc.next();
		System.out.println("성별선택 : 1.남 2.여 3.중성");
		System.out.print("입력 >> ");
		int gMenu = sc.nextInt();
		switch (gMenu) {
		case 1:
			gender = "남";
			break;
		case 2:
			gender = "여";
			break;
		case 3:
			gender = "중성";
			break;
		default:
			System.out.println("잘못된 메뉴입니다.");
			break;
		}
		System.out.print("나라 :");
		String country = sc.next();
		System.out.println("특징 : ");
		String character = sc.nextLine();
		sc.next();

		String date = "2021/03/03";

		String sql = "INSERT INTO DOG(D_CODE, D_NAME, D_AGE, D_SIZE, D_KIND, D_GENDER, D_COUNTRY, D_DATE, D_CHAR) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, code);
			pstmt.setString(2, name);
			pstmt.setInt(3, age);
			pstmt.setString(4, size);
			pstmt.setString(5, kind);
			pstmt.setString(6, gender);
			pstmt.setString(7, country);
			pstmt.setString(8, date);
			pstmt.setString(9, character);

			int count = pstmt.executeUpdate();

			if (count > 0) {
				System.out.println("등록성공!");
			} else {
				System.out.println("등록실패..");
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	public void searchDog() {
		String dCountry="";
		String dDay;
		System.out.print("검색할 나라 입력 : ");
		String country = sc.next();
		String sql = "SELECT D_CODE, D_KIND, D_NAME, D_AGE, D_SIZE, D_GENDER, D_COUNTRY, (TO_DATE(D_DATE)-SYSDATE) FROM DOG WHERE D_COUNTRY = ?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, country);
			rs = pstmt.executeQuery();
			System.out.println("검색된 강아지");
				
				while (rs.next()) {
					if (rs.getInt(8) <= 200) {
						dDay = "♥♥♥♥♥";
					} else {
						dDay = "─────";
					}
					System.out.println("┌" + dDay + "───────────────────────────────────────────────────────────────┐");
					System.out.println("\t코드:" + rs.getString(1) + "\t\t견종 : " + rs.getString(2) + "\t\t이름 : "
							+ rs.getString(3) + "\t나이 : " + rs.getString(4) + "\n\t크기 : " + rs.getString(5)
							+ "\t\t성별 : " + rs.getString(6) + "\t\t국적 : " + rs.getString(7) + "\t ※남은보호 기간 : "
							+ rs.getInt(8) + "일");

					System.out.println("└────────────────────────────────────────────────────────────────────┘");
					System.out.println();
					dCountry=rs.getString(7);
				}if (country.equals(dCountry)) {
			} else {
				System.out.println("해당 국적의 유기견은 없습니다.");
			}
		} catch (SQLException se) {

			se.printStackTrace();
		}

	}

	public void detailInfo(int code) {
		int d_code=0;
		String sql = "SELECT * FROM DOG WHERE D_CODE = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, code);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				d_code=rs.getInt(1);
					System.out.println("\t코드 :" +rs.getInt(1));
					System.out.println("\t이름 :"+rs.getString(2));
					System.out.println("\t나이 :"+rs.getInt(3));
					System.out.println("\t크기 :"+rs.getString(4));
					System.out.println("\t견종 :"+rs.getString(5));
					System.out.println("\t성별 :"+rs.getString(6));
					System.out.println("\t국적 :"+rs.getString(7));
					System.out.println("\t임시보호날짜 : "+rs.getDate(8)+"까지");
					System.out.println("\t특징 :"+rs.getString(9));
					System.out.println();
			}
			if (d_code!=code) {
				System.out.println("해당 코드의 유기견이 없습니다.");
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}

	}

	public boolean dogInfo() {
		boolean dogInfo = false;
		String dDay = null;
		String sql = "SELECT D_CODE, D_KIND, D_NAME, D_AGE, D_SIZE, D_GENDER, D_COUNTRY, (TO_DATE(D_DATE)-SYSDATE) FROM DOG";

		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			System.out.println("목록");
			while (rs.next()) {
				if (rs.getInt(8) <= 200) {
					dDay = "♥♥♥♥♥";
				} else {
					dDay = "─────";
				}
				System.out.println("┌" + dDay + "───────────────────────────────────────────────────────────────┐");
				System.out.println("\t코드 : " + rs.getString(1) + "\t견종    : " + rs.getString(2) + "\t이름 : "
						+ rs.getString(3) + "\t나이 : " + rs.getString(4) + "\n\t크기 : " + rs.getString(5) + "\t성별 : "
						+ rs.getString(6) + "\t국적 : " + rs.getString(7) + "\t남은보호 기간 : " + rs.getInt(8) + '일');
				System.out.println("└────────────────────────────────────────────────────────────────────┘");

				System.out.println();
				dogInfo = true;

			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
		return dogInfo;
	}

	public boolean adoption() {
		System.out.print("입양할 강아지 코드 입력 : ");
		int code = sc.nextInt();
		String sql = "SELECT D_NAME, D_AGE, D_SIZE, D_GENDER ,D_CODE FROM DOG WHERE D_CODE = ?";
		String sql1 = "DELETE FROM DOG WHERE D_CODE = ?";
		boolean run = true;
		boolean adoption = false;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, code);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				if (code == rs.getInt(5)) {
					adoption = true;
					System.out.println("정말로 " + rs.getString(1) + "(" + rs.getInt(2) + "살, " + rs.getString(3) + ", "
							+ rs.getString(4) + ")(을)를 입양하시겠습니까? y/n");
					while (run) {
						System.out.print("입력 >> ");
						String choose = sc.next();
						if (choose.equals("y") || choose.equals("Y")) {
							pstmt = con.prepareStatement(sql1);
							pstmt.setInt(1, code);
							pstmt.executeUpdate();
							System.out.println("입양신청이 완료되었습니다.");
							run = false;
						} else if (choose.equals("n")) {
							System.out.println("입양신청을 취소합니다.");
							run = false;
						} else {
							System.out.println("다시 입력해주세요.");

						}
					}
				} else {
					System.out.println("해당 코드의 유기견은 존재하지 않습니다.");
				}

			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
		return adoption;
	}
	public void countryInfo() {
		int n = 1;
		String sql = "SELECT DISTINCT D_COUNTRY FROM DOG ORDER BY LENGTH(D_COUNTRY) ASC";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			System.out.println("───────────────§국  가  정  보§───────────────");
			while (rs.next()) {
		
				if(n%2==0) {
					System.out.println("\t\t" + rs.getString(1));
				}
				else {System.out.print("\t"+ rs.getString(1));}
				n++;
			}
			System.out.println();
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	// shop
	public void insertGoods() {
		int code = 0;
		boolean random2 = true;

		while (random2) {
			code = (int) (Math.random() * 9999) + 1;

			String sql = "SELECT S_CODE FROM SHOP WHERE S_CODE = ?";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, code);
				rs = pstmt.executeQuery();

				if (rs.next()) {
				} else {
					random2 = false;
				}

			} catch (SQLException se) {
				se.printStackTrace();
			}
		}

		System.out.print("상품명 입력 :");
		String gName = sc.next();
		System.out.print("S사이즈 재고입력 :");
		int sMany = sc.nextInt();
		System.out.println("M사이즈 재고입력 :");
		int mMany = sc.nextInt();
		System.out.println("L사이즈 재고입력 :");
		int lMany = sc.nextInt();
		System.out.println("가격 입력 : ");
		int gPrice = sc.nextInt();

		String sql = "INSERT INTO SHOP(S_CODE, S_NAME, S_SM, S_ME, S_LA, S_PRICE) VALUES(?, ?, ?, ?, ?, ?)";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, code);
			pstmt.setString(2, gName);
			pstmt.setInt(3, sMany);
			pstmt.setInt(4, mMany);
			pstmt.setInt(5, lMany);
			pstmt.setInt(6, gPrice);

			int count = pstmt.executeUpdate();

			if (count > 0) {
				System.out.println("등록성공!");
			} else {
				System.out.println("등록실패..");
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	public void sizeInfo(String dSize) {
		if (dSize.equals("S") || dSize.equals("s")) {
			String sql = "SELECT S_CODE, S_NAME, S_SM,S_PRICE,MATERIAL FROM SHOP WHERE S_SM > 0 ORDER BY S_CODE ASC";

			try {
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					System.out
							.println("┌S사이즈─────────────────────────────────────────────────────────────────────────┐");
					if (rs.getInt(3) == 0) {
						System.out.println("※해당상품은 품절입니다.※");
					}
					System.out.print("\t상품번호: " + rs.getInt(1));
					System.out.print("/상품명: " + rs.getString(2));
					System.out.print("/재고: " + rs.getInt(3));
					System.out.print("/가격: " + rs.getInt(4));
					System.out.println("/재질: " + rs.getString(5));
					System.out.println(
							"└──────────────────────────────────────────────────────────────────────────────┘");
					System.out.println();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}

		} else if (dSize.equals("M") || dSize.equals("m")) {
			String sql = "SELECT S_CODE, S_NAME, S_ME,S_PRICE,MATERIAL FROM SHOP WHERE S_ME > 0 ORDER BY S_CODE ASC";

			try {
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					System.out
							.println("┌M사이즈─────────────────────────────────────────────────────────────────────────┐");
					if (rs.getInt(3) == 0) {
						System.out.println("※해당상품은 품절입니다.※");
					}
					System.out.print("\t상품번호: " + rs.getInt(1));
					System.out.print("/상품명: " + rs.getString(2));
					System.out.print("/재고: " + rs.getInt(3));
					System.out.print("/가격: " + rs.getInt(4));
					System.out.println("/재질: " + rs.getString(5));
					System.out.println(
							"└──────────────────────────────────────────────────────────────────────────────┘");
					System.out.println();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}
		} else if (dSize.equals("L") || dSize.equals("l")) {
			String sql = "SELECT S_CODE, S_NAME, S_LA,S_PRICE,MATERIAL FROM SHOP WHERE S_LA > 0 ORDER BY S_CODE ASC";

			try {
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					System.out
							.println("┌L사이즈─────────────────────────────────────────────────────────────────────────┐");
					if (rs.getInt(3) == 0) {
						System.out.println("※해당상품은 품절입니다.※");
					}
					System.out.print("\t상품번호: " + rs.getInt(1));
					System.out.print("/상품명: " + rs.getString(2));
					System.out.print("/재고: " + rs.getInt(3));
					System.out.print("/가격: " + rs.getInt(4));
					System.out.println("/재질: " + rs.getString(5));
					System.out.println(
							"└──────────────────────────────────────────────────────────────────────────────┘");
					System.out.println();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}
		} else {
			System.out.println("잘못 입력하였습니다.");
		}
	}

	public int randomGoods() {
		String countGoods = "select count(s_code) from shop";
		int count=0;
		try {
			pstmt = con.prepareStatement(countGoods);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				count = rs.getInt(1);
			}
			
		}catch(SQLException se) {se.printStackTrace();} //배열크기지정		
		int[] sCode = new int[count];
		
		
		
		int i =0;
		boolean random = true;
		int code = 0;
		String sql = "SELECT S_CODE FROM SHOP";

		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();     
				
			
		while (rs.next()) {
			
					sCode[i] = rs.getInt(1);
					i++;
				}              //배열값 입력
			
		} catch (SQLException se) {
			se.printStackTrace();
		}
		
		
		
		while (random) {
			code = (int) (Math.random() * 9999) + 1;
			for (i = 0; i < sCode.length; i++) {
				if (sCode[i] == code) {
					random = !random;          //일치여부확인
				}
			}
		}

		return code;
	}

	public void todayGoods(int randomCode) {

		String sql1 = "SELECT S_CODE, S_NAME, S_PRICE FROM SHOP WHERE S_CODE = ?";
		try {

			pstmt = con.prepareStatement(sql1);
			pstmt.setInt(1, randomCode);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				System.out.println("!!!!!!!!!!!!!!!!!!!!!!●○●○●○● 오늘의 상품[50% 할인!] ○●○●○●○!!!!!!!!!!!!!!!!!!!!!!");
				System.out.println("!!!!!!!!!!!!\t코드 : " + rs.getInt(1) + "\t상품명 : " + rs.getString(2) + "\t가격 : "
						+ rs.getInt(3) + " => " + (rs.getInt(3) / 2) + "\t!!!!!!!!!!!!!");
				System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
				System.out.println();
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	public void popularGoods() {
		int pCount = 1;
		String sql = "SELECT * FROM SHOP ORDER BY S_POPUL DESC";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			System.out.println("인기 상품 목록");

			while (rs.next()) {
				System.out.println("┌HIT───────────────────────────────────────────────────────────────────────┐");
				System.out.print("\t상품코드: " + rs.getString(1));
				System.out.print("/상품명: " + rs.getString(2));
				System.out.print("/가격: " + rs.getString(6) + "point");
				System.out.println("/재질: " + rs.getString(8));
				System.out.println("└──────────────────────────────────────────────────────────────────────────┘");
				System.out.println();

				pCount++;
				if (pCount == 6) {
					break;
				}
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}

	}

	public void perchase(String ID, String PW,int randomCode) {
		int sStock = 0;
		int mStock = 0;
		int lStock = 0;
		int goodsPrice = 0;

		System.out.print("제품 코드입력 :");
		int code = sc.nextInt();

		boolean run = false;
		boolean buy = false;

		String sql = "SELECT S_SM ,S_ME,S_LA FROM SHOP WHERE S_CODE = ?";
		String popularSql = "UPDATE SHOP SET S_POPUL = S_POPUL + 1 WHERE S_CODE = ?";
		String goodsPoint = "SELECT S_PRICE FROM SHOP WHERE S_CODE = ?";
		String buyPoint = "UPDATE MEMBER SET M_POINT = M_POINT-? WHERE M_ID = ?";

		try {
			pstmt = con.prepareStatement(goodsPoint);
			pstmt.setInt(1, code);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				goodsPrice = rs.getInt(1);
				run = true;
			}if(code==randomCode) {goodsPrice=goodsPrice/2;}
		} catch (SQLException se) {
			se.printStackTrace();
		}

		if (run) {
			if (checkPoint(ID) >= goodsPrice) {
				try {
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, code);
					rs = pstmt.executeQuery();

					while (rs.next()) {
						sStock = rs.getInt(1);
						mStock = rs.getInt(2);
						lStock = rs.getInt(3);

					}
				} catch (SQLException se) {
					se.printStackTrace();
				}
				System.out.print("제품 사이즈입력 [S , M , L] :  ");
				String sMenu = sc.next();

				switch (sMenu) {
				case "S":
				case "s":
				
					if (sStock != 0) {
						String invenSql1 = "UPDATE SHOP SET S_SM = S_SM - 1 WHERE S_CODE = ?";
						try {
							pstmt = con.prepareStatement(invenSql1);
							pstmt.setInt(1, code);
							pstmt.executeUpdate();

							try {
								pstmt = con.prepareStatement(popularSql);
								pstmt.setInt(1, code);
								pstmt.executeUpdate();
								buy = true;
								System.out.println("제품을 구매하였습니다.");
								try {
									pstmt = con.prepareStatement(buyPoint);
									pstmt.setInt(1, goodsPrice);
									pstmt.setString(2, ID);
									pstmt.executeUpdate();
								
								} catch (SQLException se) {
									se.printStackTrace();
								}
							} catch (SQLException se) {
								se.printStackTrace();
							}
						} catch (SQLException se) {
							se.printStackTrace();
						}
					} else {
						System.out.println("품절되엇습니다.");
					}
					break;
				case "M":
				case "m":
					if (mStock != 0) {
						String invenSql2 = "UPDATE SHOP SET S_ME = S_ME - 1 WHERE S_CODE = ?";
						try {
							pstmt = con.prepareStatement(invenSql2);
							pstmt.setInt(1, code);
							pstmt.executeUpdate();

							try {
								pstmt = con.prepareStatement(popularSql);
								pstmt.setInt(1, code);
								pstmt.executeUpdate();
								buy = true;
								System.out.println("제품을 구매하였습니다.");
								try {
									pstmt = con.prepareStatement(buyPoint);
									pstmt.setInt(1, goodsPrice);
									pstmt.setString(2, ID);
									pstmt.executeUpdate();
								} catch (SQLException se) {
									se.printStackTrace();
								}
							} catch (SQLException se) {
								se.printStackTrace();
							}
						} catch (SQLException se) {
							se.printStackTrace();
						}
					} else {
						System.out.println("품절되었습니다.");
					}

					break;
				case "L":
				case "l":
					if (lStock != 0) {
						String invenSql3 = "UPDATE SHOP SET S_LA = S_LA - 1 WHERE S_CODE = ?";
						try {
							pstmt = con.prepareStatement(invenSql3);
							pstmt.setInt(1, code);
							pstmt.executeUpdate();

							try {
								pstmt = con.prepareStatement(popularSql);
								pstmt.setInt(1, code);
								pstmt.executeUpdate();
								buy = true;
								System.out.println("제품을 구매하였습니다.");
								try {
									pstmt = con.prepareStatement(buyPoint);
									pstmt.setInt(1, goodsPrice);
									pstmt.setString(2, ID);
									pstmt.executeUpdate();
								} catch (SQLException se) {
									se.printStackTrace();
								}
							} catch (SQLException se) {
								se.printStackTrace();
							}
						} catch (SQLException se) {
							se.printStackTrace();
						}
					} else {
						System.out.println("품절되었습니다.");
					}

					break;
				default:
					System.out.println("잘못입력하였습니다.");
					break;

				}
			} else {
				System.out.println("잔여 포인트가 부족합니다.");
			}
		} else {
			System.out.println("없는 상품입니다.");
		}

	}

	public void shopInfo(int randomCode) {
		String sql = "SELECT S_CODE, S_NAME, S_PRICE FROM SHOP  ORDER BY S_CODE ASC";

		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			System.out.println("목록");

			while (rs.next()) {
				if (rs.getInt(1) == randomCode) {
					System.out.println("!!!!!!!!!!!!!!!!!!!!!!●○●○●○● 오늘의 상품[50% 할인!] ○●○●○●○!!!!!!!!!!!!!!!!!!!!!!");
					System.out.println("\t코드 : " + rs.getInt(1) + "\t상품명 : " + rs.getString(2) + "\t가격 : "
							+ (rs.getInt(3) / 2) + "point");
					System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
				} else {
					System.out.println("┌─일반상품목록──────────────────────────────────────────────────────────────────┐");
					System.out.println("\t코드 : " + rs.getInt(1) + "\t상품명 : " + rs.getString(2) + "\t가격 : "
							+ rs.getInt(3) + "point");
					System.out.println("└───────────────────────────────────────────────────────────────────────────┘");
				}
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	public void simpleInfo() {
		String sql = "SELECT S_CODE ,S_NAME,S_PRICE FROM SHOP";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println();
				System.out.print("\t상품코드 : " + rs.getInt(1));
				System.out.print("\t상품명 : " + rs.getString(2));
				System.out.println("\t가격 : " + rs.getInt(3));
				System.out.println();
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	// shared

	public void insertShared() {
		int code = 0;
		boolean random2 = true;

		while (random2) {
			code = (int) (Math.random() * 9999) + 1;

			String sql = "SELECT S_CODE FROM SHOP WHERE S_CODE = ?";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, code);
				rs = pstmt.executeQuery();

				if (rs.next()) {
				} else {
					random2 = false;
				}

			} catch (SQLException se) {
				se.printStackTrace();
			}
		}

		System.out.print("사용처 입력 :");
		String sUse = sc.next();
		System.out.print("크기입력 :");
		String sSize = sc.next();
		System.out.println("명칭 :");
		String sName = sc.next();
		System.out.println("사용기간 입력 :");
		String sDate = sc.next();
		System.out.println("상태 입력 : ");
		String sStatus = sc.next();

		String sql = "INSERT INTO DIVIDE VALUES(?, ?, ?, ?, ?, ?)";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, code);
			pstmt.setString(2, sUse);
			pstmt.setString(3, sSize);
			pstmt.setString(4, sName);
			pstmt.setString(5, sDate);
			pstmt.setString(6, sStatus);

			int count = pstmt.executeUpdate();

			if (count > 0) {
				System.out.println("등록성공!");
			} else {
				System.out.println("등록실패..");
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	public void divideInfo() {
		String sql = "SELECT * FROM DIVIDE";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			System.out.println("───────────────────────────────────나눔물품 목록───────────────────────────────────");
			while (rs.next()) {
				System.out.println("\t┌────────────────────────────────────────────────────────────┐");
				System.out.println("\t\t코드 : " + rs.getString(1) + "\t용도 : " + rs.getString(2) + "\t크기 : "
						+ rs.getString(3) + "\n\t\t이름 : " + rs.getString(4) + "\t사용기간 : " + rs.getString(5) + "\t상태 : "
						+ rs.getString(6));
				System.out.println("\t└────────────────────────────────────────────────────────────┘");
			}

		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	public boolean bring() {
		System.out.print("가져갈 물품의 코드를 입력 : ");
		int code = sc.nextInt();
		String sql = "SELECT D_NAME, D_USE, D_CODE FROM DIVIDE WHERE D_CODE = ?";
		String sql1 = "DELETE FROM DIVIDE WHERE D_CODE = ?";
		boolean run = true;
		boolean bring = false;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, code);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				if (rs.getInt(3) == code) {
					bring = true;
					System.out.println(rs.getString(1) + "(을)를 가져가시겠습니까? y/n");
					while (run) {
						System.out.print("입력 >> ");
						String choose = sc.next();
						if (choose.equals("y")) {
							pstmt = con.prepareStatement(sql1);
							pstmt.setInt(1, code);
							pstmt.executeUpdate();
							System.out.println("신청이 완료되었습니다.");
							run = false;
						} else if (choose.equals("n")) {
							System.out.println("신청을 취소합니다.");
							break;
						} else {
							System.out.println("다시 입력해주세요.");
						}
					}
				} else {
					System.out.println("잘못된 코드입니다.");
				}
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
		return bring;
	}



}
